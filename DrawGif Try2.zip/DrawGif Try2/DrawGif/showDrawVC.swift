//
//  showDrawVC.swift
//  DrawGif
//
//  Created by Ra mzy on 2/11/19.
//  Copyright © 2019 Ra mzy. All rights reserved.
//

import UIKit

class showDrawVC: UIViewController {

    var showDrawLines = [[Line]]()
    
    
    @IBOutlet weak var showDrawView: DrawView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func PlayAction(_ sender: UIButton) {
        
//       var theDrawView = showDrawView as! DrawView
//           theDrawView.lines = showDrawLines
        print("\n Count Out: \(showDrawLines.count)")
        for line in showDrawLines {

            
            
            let graphPath = UIBezierPath()
            let lineLayer = CAShapeLayer()
            
            
            for item in line {
                
                print("\n Count in: \(line.count)")
//            for item in  0...showDrawLines.count {
//
//                if item % 10 == 0 {
//                    print("\n ==> \(item)")
//                    print("\n Count: \(showDrawLines.count)")
//                    //takeImageShot()
//                }
//            }
            
//            let graphPath = UIBezierPath()
//            let lineLayer = CAShapeLayer()
            
                graphPath.move(to:  item.Start)
                graphPath.addLine(to: item.End)

                lineLayer.lineWidth         = 5.0
                lineLayer.path              = graphPath.cgPath
                lineLayer.strokeColor       = item.Color
                lineLayer.fillColor         = UIColor.clear.cgColor
                lineLayer.lineCap           = kCALineCapRound
                lineLayer.strokeEnd         = 0


                let basicAnimation          = CABasicAnimation(keyPath: "strokeEnd")
                    basicAnimation.toValue  = 1
                    basicAnimation.duration = 4
                    basicAnimation.fillMode = kCAFillModeForwards
                    basicAnimation.isRemovedOnCompletion = false

                lineLayer.add( basicAnimation,   forKey: "strokeEnd" )

//                showDrawView.layer.addSublayer(lineLayer)
//                showDrawView.layer.setNeedsDisplay()

            }
        
             showDrawView.layer.addSublayer(lineLayer)
             showDrawView.layer.setNeedsDisplay()
        }
       

        
        
//        let renderer2 = UIGraphicsImageRenderer(size: CGSize(width: 375, height: 311))
//        let img2 = renderer2.image { ctx in
//
//            for line in showDrawLines {
//
//            ctx.cgContext.move(to: line.Start)
//            ctx.cgContext.addLine(to: line.End)
//            ctx.cgContext.setStrokeColor(line.Color)
//            ctx.cgContext.strokePath()
//
//            }
//        }
//
//        imageView.image = img2
        
    }
    
    
}









