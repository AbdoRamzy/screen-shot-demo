//
//  DrawView.swift
//  DrawGif
//
//  Created by Ra mzy on 2/11/19.
//  Copyright © 2019 Ra mzy. All rights reserved.
//

import UIKit

class DrawView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

    var shape     =  [[Line]]()
    var lines     =  [Line]()
    var lastPoint :  CGPoint!
    var drawColor =  UIColor.black.cgColor
    
    required init(coder aDecoder: NSCoder!) {
        super.init(coder: aDecoder)!
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if let touch = touches.first {
            let position = touch.location(in: self)
            //print("\n X:  \(position.x) , Y:  \(position.y)")
            lastPoint = position
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
       
        if let touch = touches.first {
            let newPoint = touch.location(in: self)
            //print("\n X:  \(newPoint.x) , Y:  \(newPoint.y)")
            lines.append(Line(start: lastPoint, end: newPoint, color: drawColor))
            lastPoint = newPoint
            
        }
        
        self.setNeedsDisplay()
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        shape.append(lines)
    }
    
    override func draw(_ rect: CGRect) {
        
        let context = UIGraphicsGetCurrentContext()
            context?.setLineWidth(5.0)
            context?.setLineCap(CGLineCap.round)
        
       // for line in shape {
            
            for item in lines {
                    context?.move (to: CGPoint(x: item.Start.x, y: item.Start.y))
                    context?.addLine (to: CGPoint(x: item.End.x, y: item.End.y))
                    context?.setStrokeColor(item.Color)
                    context?.strokePath()
            }
       // }
       
    }
    
    
    
    
}





















