//
//  ViewController.swift
//  DrawGif
//
//  Created by Ra mzy on 2/11/19.
//  Copyright © 2019 Ra mzy. All rights reserved.
//

import UIKit
import ImageIO
import MobileCoreServices


class ViewController: UIViewController {

    
    @IBOutlet weak var drawView: DrawView!
    var drawColor = UIColor.black.cgColor
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //----------------------------------------------------
    @IBAction func clearBtnAction(_ sender: Any) {
    
        var theDrawView = drawView as! DrawView
            theDrawView.lines = []
            theDrawView.setNeedsDisplay()
    }
    
    //----------------------------------------------------
    @IBAction func changeColorAction(_ sender: UIButton) {
        var theDrawView = drawView as! DrawView
        var color: CGColor!
        
        if sender.titleLabel?.text == "Red" {
        
            color = UIColor.red.cgColor
            
        } else if sender.titleLabel?.text == "Black"{
            
            color = UIColor.black.cgColor
            
        }
        drawView.drawColor = color
    }
    
    //----------------------------------------------------
    
    @IBAction func showDrawAction(_ sender: UIButton) {
    

        
//        for item in  0...drawView.lines.count {
//
//            print("\n ==> \(item)")
//            if item % 10 == 0 {
//
//                print("\n Count: \(drawView.lines.count)")
//                takeImageShot()
//
//            }
//
//         }//===
        
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let balanceViewController    = storyBoard.instantiateViewController(withIdentifier: "showDrawVC") as! showDrawVC
        balanceViewController.showDrawLines = [drawView.lines]

        //print("\n\n\n Lines Count: \(drawView.lines.count)")

        self.show(balanceViewController, sender: nil)
    
    }
    
    //----------------------------------------------
    func takeImageShot (){
        
        UIGraphicsBeginImageContextWithOptions(drawView.bounds.size, false, 0.0)
        view.drawHierarchy(in: view.bounds, afterScreenUpdates: true)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        let data = UIImagePNGRepresentation(image!)
        let userDefaults = UserDefaults.standard
        userDefaults.set(data, forKey: "snapshot")
        userDefaults.synchronize()
    }
    
    //    if generateGif(arrayOfImages, "/myGIFfile.gif") {
    //    // do something with gif
    //    } else {
    //    // failed to create and close the gif file
    //    }
    
    func generateGif(photos: [UIImage], filename: String) -> Bool {
        let documentsDirectoryPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        let path = documentsDirectoryPath.appending(filename)
        let fileProperties = [kCGImagePropertyGIFDictionary as String: [kCGImagePropertyGIFLoopCount as String: 0]]
        let gifProperties = [kCGImagePropertyGIFDictionary as String: [kCGImagePropertyGIFDelayTime as String: 0.125]]
        let cfURL = URL(fileURLWithPath: path) as CFURL
        if let destination = CGImageDestinationCreateWithURL(cfURL, kUTTypeGIF, photos.count, nil) {
            CGImageDestinationSetProperties(destination, fileProperties as CFDictionary?)
            for photo in photos {
                CGImageDestinationAddImage(destination, photo.cgImage!, gifProperties as CFDictionary?)
            }
            return CGImageDestinationFinalize(destination)
        }
        return false
    }
    
    
}

