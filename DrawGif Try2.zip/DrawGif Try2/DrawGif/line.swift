//
//  lineFile.swift
//  DrawGif
//
//  Created by Ra mzy on 2/11/19.
//  Copyright © 2019 Ra mzy. All rights reserved.
//

import UIKit

class Line {
    
    var Start: CGPoint
    var End:   CGPoint
    var Color: CGColor
    
    init(start: CGPoint, end: CGPoint, color: CGColor) {
        
        Start = start
        End   = end
        Color = color
        
    }
    
}
